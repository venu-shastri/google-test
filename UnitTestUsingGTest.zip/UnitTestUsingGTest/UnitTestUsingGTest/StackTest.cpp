#include "stdafx.h"
#include <iostream>
#include <gtest\gtest.h>

class Stack {
private: int top;
		 
		 
		 int *items;

public:
	~Stack() {
		if (items) {
			delete[] items;
		}
	}
	Stack(int maxSize) {
		top = 0;
		items = new int[maxSize];
	}
	int getSize() {
		return top;
	}
	int  push(int item) {
		top++;
		return 0;

	}
};

TEST(StackTestSuite, AssertEmptyStack) {
	Stack obj(100);
	ASSERT_EQ(0, obj.getSize());
}

TEST(StackTestSuite, AssertInsertOnEmptyStack) {
	Stack obj(100);
	obj.push(1);
	ASSERT_EQ(1, obj.getSize());
}

TEST(StackTestSuite, AssertInsertManyIntemsOnStack) {
	Stack obj(100);
	obj.push(1);
	obj.push(2);
	obj.push(3);
	obj.push(4);
	ASSERT_EQ(4, obj.getSize());
}
TEST(StackTestSuite, AssertInsertOnFullSatck) {

	Stack obj(1);
	obj.push(1);
   // int status=	obj.push(2);
   //ASSERT_EQ(0, status);
   ASSERT_THROW(obj.push(2), std::out_of_range);


}