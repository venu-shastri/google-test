#include "stdafx.h"
#include <gtest\gtest.h>
#include "ShopingCart.h"
using namespace std;

//Code Under Test
class NewStack{

public: void push(int item) {}
		int pop() { return 0; }
};

//Test Fixture
class StackTestFixture :public ::testing::Test {
protected:
	NewStack *shopObj;
	virtual void SetUp() {
		shopObj = new NewStack();
	}
	virtual void TearDown() {

		delete shopObj;
	}
public:StackTestFixture() {
	//shopObj = new NewStack();
}
};


//Test Cases
TEST_F(StackTestFixture, AssertOnPushMethod) {
	

}

TEST_F(StackTestFixture, AssertTwo) {

}
