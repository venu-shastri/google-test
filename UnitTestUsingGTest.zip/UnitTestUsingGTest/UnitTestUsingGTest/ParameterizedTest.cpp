#include "stdafx.h"
#include <iostream>
#include <gtest\gtest.h>
#include <gmock\gmock.h>


class BankAccount {

public:int balance;
	   bool withdraw(int amount){
		   if (amount < balance) {
			   balance = balance - amount;
			   return true;
		}
		   else
		   {
			   return false;
		   }
	   }
	   void deposit(int amount){
		   balance = balance + amount;
	   }
};

class account_state
{
public:
	int initial_balance;
	int withdraw_amount;
	int final_balance;
	bool success;
	friend std::ostream& operator<<(std::ostream& os, const account_state& obj)
	{
		return os
			<< "initial_balance: " << obj.initial_balance
			<< " withdraw_amount: " << obj.withdraw_amount
			<< " final_balance: " << obj.final_balance
			<< " success: " << obj.success;
	}
};
class BankAccountTest : public testing::Test
{
protected:
	BankAccount* account;
public:
	BankAccountTest()
	{
		account = new BankAccount;
	}
	virtual ~BankAccountTest()
	{
		delete account;
	}
};

class WithdrawAccountTest : public BankAccountTest, public testing::WithParamInterface<account_state>
{
public:

	WithdrawAccountTest()
	{
		account->balance = GetParam().initial_balance;
		
	}
};

TEST_P(WithdrawAccountTest, FinalBalance)
{
	auto as = GetParam();
	auto success = account->withdraw(as.withdraw_amount);
	EXPECT_EQ(as.final_balance, account->balance);
	EXPECT_EQ(as.success, success);
}

INSTANTIATE_TEST_CASE_P(Default, WithdrawAccountTest,
	testing::Values(
		account_state{ 100,50,500,true }
));