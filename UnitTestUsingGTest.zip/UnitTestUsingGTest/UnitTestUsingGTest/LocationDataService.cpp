#include "stdafx.h"
#include <gtest\gtest.h>
#include <gmock\gmock.h>
#include <string>


using ::testing::_;
using namespace std;
class Location {

private:
	string locationId;
	int lat,longt;
public:
	Location(string location, int la, int lo) :locationId(location){

	}
	string getLocationId() {
		return this->locationId;
	}
};

class ILocationDataRepository {
public:
	virtual ~ILocationDataRepository(){}
	virtual string CreateNewLocation(Location *ref) = 0;
};

class  FakeLocationDataRepositoryStub:public ILocationDataRepository
{
public:
	FakeLocationDataRepositoryStub() {}
	~FakeLocationDataRepositoryStub() {}
	string CreateNewLocation(Location *locationRef) {
		return locationRef->getLocationId();
	}

private:

};

class  FakeLocationDataRepositoryMock :public ILocationDataRepository
{
public:
	FakeLocationDataRepositoryMock() {}
	~FakeLocationDataRepositoryMock() {}

	MOCK_METHOD1(CreateNewLocation, string(Location *ref));
	

private:

};




class  LocationDataService
{

public:
	LocationDataService(ILocationDataRepository *repo) {
	
		this->repoRef = repo;
	}
	~LocationDataService() {}
	string AddNewLocation(Location *locationObj) {

		return   this->repoRef->CreateNewLocation(locationObj);
		//return "test";
	}

private:
	ILocationDataRepository * repoRef;
};

 
TEST(LocationDataServiceTestSuite, AssertNewLocationCreationTest) {

	ILocationDataRepository *repo = new FakeLocationDataRepositoryStub();
	LocationDataService *service =
		new LocationDataService(repo);
	 string locationId=service->AddNewLocation(new Location("Loc1", 12, 3));
	  ASSERT_EQ("Loc1", locationId);
}

TEST(LocationDataServiceTestSuite, AssertCanAddNewLocation) {

	FakeLocationDataRepositoryMock obj;
	LocationDataService *service =new LocationDataService(&obj);
	EXPECT_CALL(obj, CreateNewLocation(_));
	string locationId = service->AddNewLocation(new Location("Loc1", 12, 3));
	//ASSERT_EQ("Loc1", locationId);
}