#include "stdafx.h"
#include <gtest\gtest.h>
#include <gmock\gmock.h>

class TestFixture:public ::testing::Test,public ::testing::WithParamInterface<int> {

public:TestFixture() {  }
	   ~TestFixture() {}
protected:
	int value = GetParam();
};


TEST_P(TestFixture, SimpleTest) {

	ASSERT_EQ(100, value);
}

INSTANTIATE_TEST_CASE_P(Default, TestFixture, ::testing::Values(100));
